#ifndef __OLED_H
#define __OLED_H
#include "sys.h"

#define LCD_SCL PBout(12)       //D0
#define LCD_SDA PBout(13)       //D1
#define LCD_CS  PBout(14)       //CS
#define LCD_DC  PBout(15)       //DC

#define XLevelL        0x00
#define XLevelH        0x10
#define XLevel         ((XLevelH&0x0F)*16+XLevelL)
#define Max_Column     128
#define Max_Row        64
#define Brightness     0xCF 
#define X_WIDTH        128
#define Y_WIDTH        64

void LCD_WrDat(u8 dat);
void LCD_WrCmd(u8 cmd);
void LCD_Set_Pos(u8 x, u8 y);
void LCD_Fill(u8 bmp_dat) ;
void LCD_CLS(void);
void LCD_Init(void);
void LCD_P6x8Str(u8 x, u8 y,u8 ch[]);
void LCD_P8x16Str(u8 x, u8 y,u8 ch[]);
void LCD_P16x16Ch(u8 x, u8 y, u8 N);
void Draw_BMP(u8 x0, u8 y0,u8 x1, u8 y1,u8 BMP[]);
extern u8 BMP[];


#endif


