#ifndef __BH1750_H
#define __BH1750_H
#include "sys.h"
#include "stdio.h"

#define	  SlaveAddress   0x46

extern u8 BUF[8]; 

void Cmd_Write_BH1750(u8 REG_Address);
void Read_BH1750(void);
void Start_BH1750(void);

#endif
