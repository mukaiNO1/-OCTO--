#ifndef __LED_H
#define __LED_H	 

#include "sys.h"

#define LED PAout(5)// 
#define BEEP PAout(4)// 	
#define RELAY PAout(6)//

void IO_Init(void);//��ʼ��

		 				    
#endif
